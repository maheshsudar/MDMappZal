---
description: Coupa flow end to end with UI5 and CAP and following the requiremebts with in MDM app.pdf
---

using @MDM app.pdf this file and support from @mcp:cap-mcp: and @mcp:ui5-mcp:, fix the end to end flow for bsuiness partner creation and at the end , is hould be in a position to cretae the business partner from the UI