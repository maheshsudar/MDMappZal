sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("com.company.couparequests.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);
